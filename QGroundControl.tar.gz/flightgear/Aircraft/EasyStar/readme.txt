Original readme:
************************************************************************
*             MULTIPLEX Modellsport GmbH & Co. KG                      *
*             Neuer Weg 2, D-75223 Niefern, Germany                    *
************************************************************************

Wir haben die Flugeigenschaften so genau wie m�glich
dem realen Modell angen�hert. In extremen Flugsituationen sind jedoch Ab-
weichungen m�glich.


This Model was created for FMS and now modified by Ken Northup using AC3D and is freely distributed.  Please feel free to modify as you wish using AC3D.  If you modify and make a better paint scheme, feel free to contact me via email, as I would love to see different versions created for Clearview RC Simulator.  To Install, simply extract the file and put the folder under the models in the Clearview RC Simulator.  The next time you run Clearview, it will appear under the Airplane selections.

Ken Northup	
Helos360@bellsouth.net